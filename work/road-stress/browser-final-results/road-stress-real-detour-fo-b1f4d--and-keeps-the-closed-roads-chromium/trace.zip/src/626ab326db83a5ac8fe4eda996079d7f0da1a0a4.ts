import { readFileSync } from "node:fs"
import AxeBuilder from "@axe-core/playwright"
import { expect, test } from "@playwright/test"
import type { StressRouteComparison } from "../src/shared/api/road-stress"
import s from "../src/shared/i18n/locales/ru/stress.json" with { type: "json" }

test("national stress workspace is keyboard accessible", async ({ page }, info) => {
  test.setTimeout(120_000)
  const errors: string[] = []
  page.on("pageerror", (error) => errors.push(error.message))
  await page.goto("/?panel=scenario")
  await expect(page.getByRole("heading", { name: s.title, exact: true })).toBeVisible({
    timeout: 60_000,
  })
  await expect(page.getByText(s.select, { exact: true })).toBeVisible()
  await expect
    .poll(async () => Number(await page.locator("[data-map-surface]").getAttribute("data-zoom")), {
      timeout: 90_000,
    })
    .toBeGreaterThan(0)
  await page.screenshot({ path: info.outputPath("stress-workspace-1440.png") })
  const result = await new AxeBuilder({ page }).include("main").analyze()
  expect(result.violations).toEqual([])
  expect(errors).toEqual([])
})

test("saved national result survives reload and opens its map", async ({ page, request }, info) => {
  test.setTimeout(120_000)
  const id = process.env.STRESS_JOB_ID
  if (!id) throw new Error("Prepare a completed real national stress test and set STRESS_JOB_ID")
  const response = await request.get(`/api/v1/road-stress-tests/${id}`)
  expect(response.ok()).toBeTruthy()
  expect((await response.json()).status).toBe("completed")
  await page.goto(`/?panel=scenario&stress=${id}`)
  await expect(page.getByRole("button", { name: s.overview, exact: true })).toBeVisible()
  await page.getByRole("button", { name: s.overview, exact: true }).click()
  await page.reload()
  await expect(page.getByRole("button", { name: s.overview, exact: true })).toBeVisible()
  await expect
    .poll(async () => Number(await page.locator("[data-map-surface]").getAttribute("data-zoom")), {
      timeout: 90_000,
    })
    .toBeGreaterThan(0)
  await page.getByRole("button", { name: s.overview, exact: true }).click()
  await expect(page.locator("[data-stress-job]")).toHaveAttribute("data-stress-job", id)
  await expect
    .poll(
      async () =>
        Number(await page.locator("[data-stress-closed]").getAttribute("data-stress-closed")),
      { timeout: 60_000 },
    )
    .toBeGreaterThan(0)
  await page.setViewportSize({ width: 1920, height: 1080 })
  await page.screenshot({ path: info.outputPath("stress-result-1920.png") })
})

test("real detour form renders both paths and keeps the closed roads", async ({ page }, info) => {
  test.setTimeout(240_000)
  const id = process.env.STRESS_JOB_ID
  if (!id) throw new Error("Set STRESS_JOB_ID to the completed M-10 scenario")
  const route = JSON.parse(
    readFileSync(new URL("../../work/road-stress/route-validation.json", import.meta.url), "utf8"),
  ) as StressRouteComparison
  await page.goto(`/?panel=scenario&stress=${id}`)
  await page.getByRole("button", { name: s.route, exact: true }).click()
  await page
    .getByRole("combobox", { name: s.origin, exact: true })
    .fill(route.origin.name.replace(/^.*? /, ""))
  await page.getByRole("option").filter({ hasText: route.origin.name }).first().click()
  await page
    .getByRole("combobox", { name: s.destination, exact: true })
    .fill(route.destination.name.replace(/^.*? /, ""))
  await page.getByRole("option").filter({ hasText: route.destination.name }).first().click()
  const response = page.waitForResponse(
    (r) => r.url().includes(`/${id}/routes`) && r.request().method() === "POST",
    { timeout: 180_000 },
  )
  await page.getByRole("button", { name: s.compare, exact: true }).click()
  expect((await response).ok()).toBeTruthy()
  await expect(page.getByText(s.before, { exact: true })).toBeVisible()
  await expect(page.getByText(s.after, { exact: true })).toBeVisible()
  await expect(page.locator("[data-stress-job]")).toHaveAttribute("data-stress-job", id)
  await expect
    .poll(async () =>
      Number(await page.locator("[data-stress-closed]").getAttribute("data-stress-closed")),
    )
    .toBeGreaterThan(0)
  await page.screenshot({ path: info.outputPath("stress-detour-1440.png") })
})
